# Hourly rate calculator (do this once)
1. Target yearly take-home income: **T**
2. Yearly business costs (software, hardware, insurance, accountant): **C**
3. Taxes & social contributions (% of profit): **p** → needed gross = (T + C) / (1 − p)
4. Billable hours per year: 52 weeks − 6 weeks off/holidays/sick = 46 weeks × 30 billable h/week (the rest is admin, sales) = **1380 h**
5. **Minimum hourly rate = needed gross / 1380**
Example: T = 40 000, C = 4 000, p = 25% → 44 000 / 0.75 = 58 667 → **≈ 42.5 / h**.
Fixed-price quote = hours estimate × rate × 1.3 (buffer for unknowns) — never quote the optimistic estimate.
