# Finding clients: outreach templates
**Cold email (≤90 words):** Subject: Quick idea for [Company]'s [page/process]
Hi [Name], I noticed [specific, true observation, e.g. checkout page loads in 6s on mobile]. I help [type of company] with [outcome] — for example [one concrete result/sample]. Would a 2-page plan of fixes be useful? Happy to send it, no strings. — [You]
**Follow-up 1 (day 4):** "Bumping this in case it got buried — still glad to share the short plan. Not a fit? Tell me and I'll stop."
**Follow-up 2 (day 10):** "Last note from me. Here's one tip you can use right now regardless: [useful tip]. If priorities change, I'm at [email]."
**After a call:** "Thanks for your time. My understanding: [goal], [scope], [deadline]. Proposal attached; it's valid until [date]. Next step is your reply 'Approved' and I'll invoice the deposit."
**Asking for a testimonial (on delivery):** "Glad it's live! If you're happy, could you reply with 2–3 sentences on (1) what was the problem, (2) what changed, (3) who you'd recommend me to? I'd love to feature it, with your permission."
**Referral ask (30 days later):** "Is there anyone in your network facing something similar? I keep a few slots each month for referrals and give past clients [x]% off the next project."
**Rules:** one clear ask per email; personalize the first line honestly; only email businesses that plausibly need the service; include opt-out; follow the anti-spam laws of your country.
