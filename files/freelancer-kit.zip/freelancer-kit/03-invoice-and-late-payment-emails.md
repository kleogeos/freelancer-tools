# Invoice template
**INVOICE #[YYYY-001]** · Issue date: [ ] · Due: [ ] (Net [7])
From: [Name, address, tax ID] · To: [Client, address, VAT/tax ID]
| Description | Qty | Rate | Amount |
|---|---|---|---|
| [Milestone 1 — description] | 1 | [ ] | [ ] |
Subtotal / Tax ([ ]%) / **Total due**
Payment: [bank IBAN/SWIFT or payment link]. Reference: INV-[ ].
Late fee: [1.5]% per month after due date.

# Payment reminder emails (copy & paste)
**Day -2 (friendly):** Subject: Invoice [#] due on [date]
Hi [Name], a quick heads-up that invoice [#] ([amount]) is due on [date]. Payment details are on the invoice; let me know if you need anything from my side. Thanks!

**Day +3:** Subject: Invoice [#] — now past due
Hi [Name], I haven't received payment for invoice [#] ([amount]), which was due on [date]. Could you confirm when I can expect it? If it has been paid, please send the transfer reference.

**Day +10:** Subject: Second reminder — invoice [#]
Hi [Name], following up on invoice [#], now [N] days overdue. Per our agreement, a late fee of [x]% applies from [date]. Please arrange payment by [date] — I'd like to keep our work on schedule, and I'll pause further work until the balance is cleared.

**Day +21 (final):** Subject: Final notice — invoice [#]
Hi [Name], invoice [#] remains unpaid ([amount + fee]). Unless I receive payment by [date], I'll have to pass the matter to formal collection / small-claims proceedings. I'd much rather resolve this directly — please reply today with a payment date.
