# Project Proposal — [PROJECT NAME]
Prepared for: [CLIENT] · Prepared by: [YOU] · Date: [DATE] · Valid until: [DATE + 14 days]

## 1. Understanding of the problem
In 2–3 sentences, restate the client's goal in their own words. Example: "You need X so that Y, currently blocked by Z."

## 2. Scope (what is included)
- Deliverable 1: [concrete, testable]
- Deliverable 2: [concrete, testable]
- Deliverable 3: [concrete, testable]

## 3. Out of scope
List what is *not* included (hosting, content writing, third-party fees, post-launch support beyond [N] days). Anything not listed in section 2 is a change request.

## 4. Approach & timeline
| Milestone | Outcome | Date |
|---|---|---|
| M1 Kickoff & requirements | Written brief signed off | [ ] |
| M2 First working version | Demo link | [ ] |
| M3 Revisions | Up to [2] rounds | [ ] |
| M4 Delivery | Files / deploy / handover | [ ] |

## 5. Price & payment
- Fixed fee: [AMOUNT] [CURRENCY] (or hourly: [RATE], estimate [HOURS]h, cap [HOURS]h)
- 40% to start, 30% at M2, 30% on delivery. Invoices due in [7] days.

## 6. Assumptions
Client provides access/assets within [3] business days; one point of contact; feedback within [2] business days. Delays extend the timeline equally.

## 7. Next step
Reply "Approved" or sign below and I will send the first invoice and book the kickoff.
