# Freelancer Starter Kit — proposals, contract, invoices, scripts
Seven copy-and-paste documents (Markdown, open in any editor / paste into Google Docs or Word):
1. Proposal template  2. Services agreement template  3. Invoice + 4 payment-reminder emails  4. Client communication scripts  5. Pricing calculator  6. Client intake questionnaire  7. Outreach & follow-up emails
Fill every [BRACKET]. Contract is a general template, not legal advice.
