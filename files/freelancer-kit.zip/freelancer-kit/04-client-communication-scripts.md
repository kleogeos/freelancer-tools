# Scripts for hard client moments
**Scope creep:** "Happy to add that. It's outside the agreed scope, so I'd estimate [X h / $Y] and it would move delivery to [date]. Want me to go ahead, or keep to the original plan?"
**Asking for a deposit:** "To reserve your slot I start projects after a [40]% deposit. I'll send the invoice now and kick off as soon as it's paid."
**Client goes silent:** "Hi [Name], to keep [date] on track I need your feedback on [item] by [date]. If I don't hear back, I'll move on to the next task and the delivery date shifts accordingly."
**Unreasonable discount ask:** "I can't lower the rate without lowering the scope. Option A: full scope at [price]. Option B: reduced scope [list] at [price]."
**Endless revisions:** "We've completed the [2] included revision rounds. Further changes are billed at [rate]/hour; shall I send an estimate?"
**Saying no politely:** "Thanks for thinking of me. I'm fully booked until [date]. I can recommend [name], or take it on after [date] if the timing works."
**Raising your rates:** "From [date] my rate for new work is [X]. Your current project stays at the existing rate until [date]."
