# Client intake questionnaire (send before quoting)
1. What is the business and who are its customers?
2. What problem should this project solve? How will you know it worked (metric, date)?
3. What exists today (site, code, brand assets, accounts)? Who owns the access?
4. Must-haves vs nice-to-haves (rank top 5).
5. Examples you like / dislike, and why.
6. Deadline and what drives it (launch, event, budget cycle).
7. Budget range. (If unsure: "projects like this typically cost A–B; does that fit?")
8. Who approves the work? Who else gives feedback? Max feedback turnaround?
9. Legal/compliance constraints (GDPR, accessibility, licences, NDAs)?
10. What happens after launch: maintenance, hosting, support — who and how long?
**Red flags to price in:** many approvers, "we'll know it when we see it", no budget answer, wants spec work for free, refuses a deposit.
