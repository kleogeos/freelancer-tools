# Freelance Services Agreement (template)
> Template for general guidance, not legal advice. Have a qualified lawyer review it for your jurisdiction before relying on it.

**Parties:** [CLIENT LEGAL NAME] ("Client") and [YOUR NAME/COMPANY] ("Contractor"). Effective date: [DATE].

1. **Services.** Contractor will perform the services described in the attached Proposal/SOW ("Services").
2. **Fees & payment.** Client pays the fees in the SOW. Invoices are due within [7/14] days. Late amounts accrue [1.5]% interest per month (or the maximum allowed by law, if lower).
3. **Expenses.** Pre-approved third-party costs are reimbursed at cost.
4. **Change requests.** Work outside the SOW requires written agreement on price and timeline before it starts.
5. **Revisions.** [2] rounds of revisions are included; further rounds are billed at [RATE]/hour.
6. **Client responsibilities.** Timely access, feedback and materials. Delays caused by the Client extend deadlines.
7. **Intellectual property.** On full payment, Contractor assigns to Client the rights in the final deliverables created specifically for Client. Contractor keeps pre-existing tools, libraries and know-how and grants Client a perpetual licence to use them as embedded in the deliverables. Until full payment, Contractor retains all rights.
8. **Portfolio.** Contractor may show the work in a portfolio unless Client objects in writing [before delivery].
9. **Confidentiality.** Each party keeps the other's non-public information confidential for [2] years after termination.
10. **Warranties & liability.** Services are provided with reasonable skill and care. Contractor's total liability is limited to the fees paid under this Agreement. Neither party is liable for indirect or consequential losses.
11. **Independent contractor.** Contractor is not an employee; Contractor handles own taxes and tools.
12. **Termination.** Either party may terminate with [7] days' written notice. Client pays for work done to the termination date plus non-cancellable costs. Kill fee for fixed-price projects: [20]% of the unpaid balance.
13. **Governing law.** [JURISDICTION]. Disputes: good-faith negotiation first, then [courts/arbitration] of [CITY].
14. **Entire agreement.** This Agreement and the SOW are the whole agreement; changes must be in writing.

Signed: ______________ (Client)  Date: ______   Signed: ______________ (Contractor)  Date: ______
