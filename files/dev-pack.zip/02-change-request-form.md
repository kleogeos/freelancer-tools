# Change Request #[n]
**Project:** [name] **Requested by:** [name] **Date:** [date]
**Description of change:**
**Reason / business value:**
**Impact:** extra hours [x] × rate [r] = cost [c]; timeline moves by [d] days.
**Approval:** Client signature / reply "approved" by email: ____ Date: ____
Work on this change starts only after approval.
