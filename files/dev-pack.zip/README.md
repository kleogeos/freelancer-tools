# Freelance Web Developer Pack
Scope template, change request form, handover checklist, discovery questions. Plain Markdown. Not legal advice; have a lawyer review contract terms for your jurisdiction.
