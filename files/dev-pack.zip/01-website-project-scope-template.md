# Website / Web App Project Scope (fill in and attach to the contract)
**Client:** [name] **Project:** [name] **Date:** [date]

## 1. Goal
One sentence on the business result (e.g. "collect 50 qualified leads per month").

## 2. Deliverables (included)
- [ ] Pages/screens: [list, with count]
- [ ] Responsive layouts: mobile, tablet, desktop
- [ ] CMS / admin: [yes/no, which system]
- [ ] Integrations: [payments, email, analytics — name each]
- [ ] Basic SEO setup (titles, meta, sitemap, redirects)
- [ ] Deployment to [host] and handover of access

## 3. Explicitly NOT included
Copywriting, photography, logo/branding, content entry beyond [N] pages, hosting fees, third-party licences, ongoing maintenance, browser support below [list], translations.

## 4. Client responsibilities
Provide content by [date], one point of contact, feedback within [3] business days. Delays move the timeline by the same number of days.

## 5. Revisions
[2] rounds of consolidated feedback per milestone. Additional rounds: [rate]/hour.

## 6. Milestones and payment
| Milestone | Deliverable | Due | Payment |
|---|---|---|---|
| Kickoff | Signed scope | [date] | 40% |
| Design approved | Mockups | [date] | 30% |
| Launch | Live site | [date] | 30% |

## 7. Change requests
Anything not listed in section 2 is a change request: I estimate hours and cost in writing and work starts after approval.

## 8. Acceptance
Work is accepted after [5] business days without reported defects, or on launch. Defect fixes for [30] days after launch are free.
