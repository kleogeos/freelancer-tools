# Technical Discovery Questions (ask before quoting)
1. What business goal should this site/app achieve, and how will you measure it?
2. Who are the users and what are their top 3 tasks?
3. Is there an existing site, brand guide or design? Who owns the domain and hosting?
4. Which systems must it connect to (CRM, payments, email, ERP)? Do you have API access?
5. Who supplies content, and by when? Who approves work?
6. Languages, accessibility requirements, supported browsers/devices?
7. Expected traffic and data volume? Any compliance needs (GDPR, cookies, payments)?
8. Who maintains it after launch? Is there a budget for changes?
9. Hard deadline and the reason for it? Budget range?
10. What happened with previous developers or agencies?
