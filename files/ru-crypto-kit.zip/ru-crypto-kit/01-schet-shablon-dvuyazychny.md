# Шаблон счёта (Invoice) для иностранного клиента — двуязычный

Зарубежному заказчику нужен документ на английском. Ниже — готовый шаблон:
скопируйте, замените поля в [квадратных скобках], отправьте клиенту как PDF
или просто текстом письма.

---

**INVOICE**

Invoice #: [001]
Date: [15 October 2026]
Due: [Net 14 — 29 October 2026]

**From:** [Ваше имя], [город, страна]
Email: [ваш email]

**To:** [Имя клиента]
[Адрес клиента / компания]

| Description | Qty | Rate | Amount |
|---|---|---|---|
| [Описание услуги, напр. "Web development — Sprint 3"] | [1] | [$1,200] | [$1,200] |

**Total due: [$1,200 USD]**

**Payment methods:**
- Bank transfer (SWIFT): [реквизиты, если есть валютный счёт]
- USDT (TRC20): [ваш адрес кошелька] — см. QR-код и инструкцию ниже

---

## Что писать в поле Description, если клиент не любит подробностей

Короткая формулировка понятнее длинной: "Web development — Sprint 3" лучше,
чем подробный лог коммитов. Если нужна детализация — вынесите её в отдельное
приложение (Scope of work), а в счёте оставьте одну строку на этап/спринт.

## Почему сумма в USD/EUR, а не в рублях

Зарубежному клиенту проще сверить сумму в его валюте со своим бюджетом.
Рублёвая сумма заставит его считать курс самостоятельно — лишний повод
задержать оплату или написать с вопросом.

## QR-код и инструкция для клиента, если платит в USDT

Приложите к счёту текст (на английском, скопируйте как есть):

> To pay this invoice in USDT (TRC20 network), send [$1,200] worth of USDT to
> the address below. Please double-check the network is TRC20 before sending —
> other networks are not supported.
>
> Wallet address: [ваш адрес]
> [вставьте QR-код — можно сгенерировать бесплатно на api.qrserver.com/v1/create-qr-code/?data=ВАШ_АДРЕС]
>
> Once sent, please reply with the transaction hash so I can confirm receipt.

Подробнее про саму настройку приёма USDT — в гайде
[«Как фрилансеру принимать оплату в крипте»](https://kleogeos.github.io/freelancer-tools/kak-frilanseru-prinimat-kripto-oplatu.html).
