# 4 письма-напоминания об оплате (для иностранного клиента, на английском)

Отправляются по очереди: дружеское напоминание → настойчивое → с упоминанием
пени → финальное. Замените поля в [квадратных скобках].

## 1. За 3 дня до срока оплаты — дружеское напоминание

Subject: Quick reminder — Invoice #[001] due [29 Oct]

> Hi [Имя],
>
> Just a friendly heads-up that invoice #[001] for [$1,200] is due on [29 Oct].
> Let me know if you need anything from me to process it.
>
> Thanks!
> [Ваше имя]

## 2. В день просрочки

Subject: Invoice #[001] — now overdue

> Hi [Имя],
>
> Invoice #[001] ([$1,200]) was due on [29 Oct] and I don't see payment yet.
> Could you confirm when it's being processed?
>
> Thanks,
> [Ваше имя]

## 3. Через 7 дней просрочки — с упоминанием пени

Subject: Invoice #[001] — 7 days overdue

> Hi [Имя],
>
> It's been a week since invoice #[001] ([$1,200]) was due. Per our agreement,
> a late fee of [1.5%/month] applies after [7] days. I'd rather not add it —
> could we get this resolved this week?
>
> [Ваше имя]

## 4. Финальное уведомление

Subject: Invoice #[001] — final notice before [action]

> Hi [Имя],
>
> This is a final notice for invoice #[001] ([$1,200] + [late fee]), now
> [21] days overdue. If I don't receive payment or hear back by [дата], I'll
> need to [pause further work / escalate per our contract].
>
> [Ваше имя]

---

## Если клиент предлагает оплатить в крипте, но раньше не платил так

Коротко объясните, что это не "что-то подозрительное", а обычный способ
получить деньги быстро без банковских задержек:

> No problem — I can also accept USDT (a dollar-pegged stablecoin) if that's
> easier on your end. It settles in seconds and avoids international wire fees.
> I'll send the wallet address and a QR code separately.

Подробный разбор площадок/комиссий — в [сравнении комиссий USDT по сетям](https://kleogeos.github.io/freelancer-tools/crypto-fee-comparison.html).
