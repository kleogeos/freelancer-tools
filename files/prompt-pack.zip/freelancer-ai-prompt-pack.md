# 40 AI Prompts for Freelancers
Copy a prompt into ChatGPT, Claude or any assistant. Replace [BRACKETS] with your details. Always review the output before sending it to a client.

## 1. Finding clients
1. **Niche picker** — "I am a freelance [SKILL] with experience in [INDUSTRIES]. List 10 niches where businesses pay well for this skill, and for each: the typical problem, who the buyer is, and a one-line offer I could make."
2. **Ideal client profile** — "Build an ideal client profile for my [SERVICE]: company size, role of the decision maker, budget range, triggers that make them hire, and 5 places to find them online."
3. **Cold email v1** — "Write a 90-word cold email to [ROLE] at [COMPANY TYPE]. I noticed [SPECIFIC OBSERVATION]. I offer [RESULT]. End with a low-pressure question. No hype words."
4. **Cold email follow-ups** — "Write 3 follow-up emails (day 3, day 7, day 14) for my cold email below. Each adds new value, none says 'just checking in'. Email: [PASTE]"
5. **LinkedIn opener** — "Write 5 different LinkedIn connection notes under 280 characters for [ROLE] in [INDUSTRY], referencing [SHARED CONTEXT]."
6. **Profile rewrite** — "Rewrite my freelance profile headline and bio so a client immediately sees who I help, what result I deliver, and proof. Current text: [PASTE]"
7. **Job post analysis** — "Here is a job post: [PASTE]. Tell me what the client really wants, red flags, questions to ask, and a realistic budget."
8. **Marketplace proposal** — "Write a 120-word proposal for this job post: [PASTE]. Start with their problem, show one relevant result of mine ([RESULT]), propose a first step, ask one sharp question."

## 2. Pricing and proposals
9. **Rate sanity check** — "I charge [RATE] for [SERVICE] in [MARKET]. Give arguments for and against raising it, and a plan to raise it for new clients by 20%."
10. **Value-based quote** — "Client goal: [GOAL]. Estimate the business value of reaching it and propose three packages (basic, standard, premium) with scope and price anchored to value."
11. **Scope breakdown** — "Break this project into tasks with hour estimates, a 25% risk buffer, and dependencies: [PROJECT]"
12. **Proposal draft** — "Write a one-page proposal: problem, approach, deliverables, timeline, price, terms, next step. Project notes: [PASTE]. Tone: confident, plain."
13. **Price objection reply** — "The client said: '[OBJECTION]'. Write 3 replies: one that reduces scope instead of price, one that explains value, one that politely holds the price."
14. **Out-of-scope request** — "Client asked for [EXTRA]. It was not in scope [PASTE SCOPE]. Write a friendly message offering a change order with price and timeline impact."
15. **Rush fee** — "Write a short message explaining a 30% rush fee for delivery in [DAYS] days, without sounding defensive."

## 3. Contracts and admin (not legal advice)
16. **Contract checklist** — "List the clauses a [SERVICE] freelance contract in [COUNTRY] should include: scope, revisions, payment, IP, kill fee, confidentiality, liability. Explain each in plain words."
17. **Contract red flags** — "Read this client contract and list clauses that are risky for a freelancer, with a suggested rewrite for each. Recommend which points to confirm with a lawyer. [PASTE]"
18. **Kickoff email** — "Write a kickoff email confirming scope, timeline, communication channel, what I need from the client and by when. Project: [DETAILS]"
19. **Invoice reminder 1** — "Write a polite reminder for invoice [NUMBER], [AMOUNT], due [DATE], 3 days overdue."
20. **Invoice reminder 2** — "Write a firm second reminder 14 days overdue citing the agreed payment terms and a new deadline."
21. **Final notice** — "Write a final payment notice that states consequences allowed by my contract (pause work, late fee) without threats."
22. **Offboarding** — "Write a project wrap-up email: deliverables list, handover instructions, final invoice, request for a testimonial, and an offer for ongoing support."

## 4. Delivering work
23. **Discovery questions** — "I am about to start [PROJECT TYPE] for a [CLIENT TYPE]. Give me 15 discovery questions that prevent scope creep and rework."
24. **Meeting notes to actions** — "Turn these notes into decisions, action items with owners and dates, and open questions: [PASTE]"
25. **Status update** — "Write a weekly client update: done, next, blockers, decisions I need. Keep under 120 words. Data: [PASTE]"
26. **Feedback decoder** — "The client gave this vague feedback: '[FEEDBACK]'. List 5 possible meanings and clarifying questions to ask."
27. **Revision limit** — "Write a kind message explaining that revision round [N] of [MAX] is complete and what extra rounds cost."
28. **Bad news** — "I will miss the deadline by [DAYS] days because [REASON]. Write an honest message with a new date and what I do to prevent further slips."
29. **Difficult client** — "A client keeps changing requirements and writing late at night. Write boundaries to set: working hours, response times, change process. Give me the message."

## 5. Growth and retention
30. **Testimonial request** — "Write a short message asking [CLIENT] for a testimonial with 3 easy prompts to answer."
31. **Case study** — "Turn these facts into a one-page case study (problem, approach, result, quote): [PASTE]"
32. **Upsell** — "Based on the project I delivered ([DETAILS]), suggest 3 follow-up services and write a short message proposing the best one."
33. **Retainer offer** — "Design a monthly retainer for [SERVICE]: included hours, response time, rollover rule, price, and the pitch message."
34. **Referral ask** — "Write a referral request to a happy client that makes it easy to introduce me, with a draft they can forward."
35. **Reactivation** — "Write a message to a client I haven't worked with for [MONTHS] months, referencing [LAST PROJECT], offering a useful idea rather than asking for work."
36. **Content ideas** — "Give me 20 post ideas for [PLATFORM] that show expertise in [SKILL] to [CLIENT TYPE], each with a hook."

## 6. Business of one
37. **Weekly plan** — "I have [HOURS] hours this week. Projects: [LIST]. Build a day-by-day plan with 20% buffer and one block for sales."
38. **Monthly review** — "Here are my numbers: income [X], hours [Y], clients [Z]. Calculate effective hourly rate, find my least profitable client type, and give 3 changes."
39. **Fire a client** — "Write a professional message ending the relationship with a client because [REASON], with a transition plan."
40. **Quarterly goals** — "Help me set 3 measurable goals for the next 90 days for my freelance business, with weekly actions. Context: [PASTE]"

---
Not legal, tax or financial advice. Results depend on your input and review.
